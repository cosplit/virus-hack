# Setup

* Install [TeXLive 2020](https://tug.org/texlive/acquire-netinstall.html)
* Compile main.tex with pdflatex
* VS Code: Get the [LaTeX Workshop](https://marketplace.visualstudio.com/items?itemName=James-Yu.latex-workshop) extension